import java.text.DecimalFormat;

public class Minivan extends Vehicle
{
	private double length, width;
	private static DecimalFormat dec2 = new DecimalFormat(".###");

	public Minivan(
		String make, String model, int year, String status, int id, 
		double cost, double length, double width){

		super(make, model, year, status, id, cost);		
		this.length = length;
		this.width = width;
	}


	public void info(boolean isRent)
	{
		if(isRent)
		{
			if(this.status.equals("RENTAL")) _infoHelper();
		}
		else _infoHelper();
	}


	public void _infoHelper()
	{
		int ID      = this.id;
		double COST = this.cost;

		System.out.print(" ID: " + ID);
		genSpace( intLength(ID) , 14);
		System.out.print("COST $" + dec2.format(COST));
		genSpace( 4 , 8);
		System.out.println("[" + this.status + "]");
		System.out.println(" MINIVAN: " + this.year + " " + 
								 this.make + " " + this.model);
		System.out.println(" LENGTH: " + length + "    " + "WIDTH: " + width + "\n");		
	}


	int intLength(int value)
	{
		return (Integer.toString(value)).length();
	}


	void genSpace(int x, int maxSpace)
	{
		int limit = maxSpace - x;
		for(int i = 0; i < limit; i++)
		{
			System.out.print(" ");
		} 

	}


	public boolean findID(int id)
	{
		if(this.id == id) return true;
		return false;
	};


	public void update(String newState)
	{
		this.status = newState;
	};
}