public class node
{
    private Vehicle vehicle; 
    private node next;
   
    node (Vehicle vehicle){                               
     this.vehicle = vehicle;
      next = null;
    }

    public void displayInfo(boolean isRent){
    	vehicle.info(isRent);
    }  

    public boolean searchID(int id){	    	
        if( vehicle.findID(id) ) return true;
        else return false;
    }

    public void update(String newState)
    {
        vehicle.update(newState);
    }

    public Vehicle getVehicle(){return vehicle;}
    public void setNext(node n){next = n;}   
    public node getNext() {return next; }    
}