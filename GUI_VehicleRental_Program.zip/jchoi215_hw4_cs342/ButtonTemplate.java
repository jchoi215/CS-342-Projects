import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Dimension;

public class ButtonTemplate extends JPanel
{
	private JButton[] button;

	// create buttons: set position and store in ARRAY
	public ButtonTemplate()
	{
		button = new JButton[6];
		button[0] = buildButton(429, 25, 169, 52);
		button[1] = buildButton(25, 614, 169, 59);
		button[2] = buildButton(213, 614,155, 59);
		button[3] = buildButton(617, 25, 198, 52);
		button[4] = buildButton(840, 25, 135, 52);
		button[5] = buildButton(390, 614, 69, 59);
	}

	// create buttons w/ icon
	JButton buildButton(int x, int y, int btn_width, int btn_height)
	{
		JButton stateButton = new JButton(new ImageIcon("overLay.png"));
		stateButton.setContentAreaFilled(false);
		stateButton.setBorder(null);
		stateButton.setFocusPainted(false);
		stateButton.setBorderPainted(false);
		stateButton.setBounds (x, y, btn_width, btn_height);
		return stateButton;
	}

	// pass the JButton to other programs
	public JButton[] getButtons(){return button;}
}