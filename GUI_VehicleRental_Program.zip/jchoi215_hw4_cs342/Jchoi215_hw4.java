import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.Color;

public class Jchoi215_hw4
{
	public static void main(String[] args) {

		// create the JFrame that is going to encapsulate all the JPanels
		JFrame frame = new JFrame(); 
		VehicleRentalManager manager = new VehicleRentalManager();
		manager.setBackground(Color.BLACK);
		
		// add JPanel, make it visable, fixed size and add title
		frame.add(manager);
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.setTitle("Vehicle Rental Manager Program");
		frame.setSize(1000, 750);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
