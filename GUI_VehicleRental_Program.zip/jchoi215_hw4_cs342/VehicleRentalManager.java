import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.Timer;
import java.awt.Color;
import java.util.Scanner;

import java.util.InputMismatchException;

public class VehicleRentalManager extends JPanel implements ActionListener, MouseListener
{
	private VehicleLinkedList vehicleList;
	private InterfaceImage status;
	private ButtonTemplate button;
	
	private JButton[] inputButtons;
	private JButton activeBtn;
	private JLabel[]  inputOptions;
	private JLabel  activeStatus;
	private Scanner getInput;

	private int idStart = 0;
	private int trigger = 0;

	// constuctor creating all JPanels and JLabels and add them
	public VehicleRentalManager()
	{
		vehicleList = new VehicleLinkedList();
		getInput    = new Scanner(System.in);
		
		this.setLayout(null);
		status = new InterfaceImage();
		button = new ButtonTemplate();
		inputButtons = new JButton[6];
		inputOptions = new JLabel[7];

		inputOptions = status.getOptions();
		inputButtons = button.getButtons();

		addButtons();
		addOptions();
		
		inputOptions[6].setVisible(true);
		inputOptions[6].addMouseListener(this);
		activeStatus = inputOptions[6];
		
		out("\nClick on commands in GUI!\n\n");
	}


	// add listener to all the buttons and add them to the program
	private void addButtons() {
		for(int i = 0; i < 6; i++)
		{
			inputButtons[i].addActionListener(this);
			this.add(inputButtons[i]); 		
		}
	}

	// add listener to all JLabels
	private void addOptions()
	{
		for(int i = 0; i < 7; i++) this.add(inputOptions[i]); 
	}

    // GUI -- when clicked DO these actions
	public  void actionPerformed(ActionEvent e)
	{	
		if(e.getSource() == inputButtons[0]  )      // ADD
		{
			out("\nCOMMAND: ADD\n------------\n");
			updateCurSettings(0);

			Timer timer = new Timer(150, new ActionListener(){
		       public void actionPerformed(ActionEvent e)
		       { commandAdd();}});
		       timer.setRepeats(false);
		       timer.start();

		       
		}  
		else if(e.getSource() == inputButtons[3]  )  // UPDATE  
		{
			out("\nCOMMAND: UPDATE\n---------------\n");
			updateCurSettings(3);

			Timer timer = new Timer(150, new ActionListener(){
		       public void actionPerformed(ActionEvent e)
		       { commandUpdate(); instruction(); }}); 
				timer.setRepeats(false);
				timer.start();  
		}  
		else if(e.getSource() == inputButtons[4]  )  // RESET 
		{
			out("\nCOMMAND: RESET\n--------------\n");
			out(" DATA CONTENT CLEARED\n");
			idStart = 0;
			updateCurSettings(4);
			vehicleList.deleteList();
		}  
		else if(e.getSource() == inputButtons[1]  )  // SHOW ALL 
		{
			out("\nCOMMAND: SHOW ALL\n-----------------\n");
			updateCurSettings(1);
			vehicleList.showList();
		}  
		else if(e.getSource() == inputButtons[2]  )  // RENT
		{
			out("\nCOMMAND: RENT\n-------------\n");
			updateCurSettings(2);
			vehicleList.rentable();
		}  
		else if(e.getSource() == inputButtons[5]  )  // EXIT
		{
			out("\nCOMMAND: EXIT\n");
			updateCurSettings(5); 
			createDelay(100);
		}  
	}
	

	private void instruction()
	{
		out("\n\nClick on commands in GUI!\n\n");
	}

	private void commandUpdate()
	{
		int findId = getInt("INPUT VEHICLE ID: ");	
		vehicleList.updateStatus(findId);
	}

	private void updateCurSettings(int i)
	{
		activeStatus.setVisible(false);
		inputOptions[i].setVisible(true);
		inputOptions[6].setVisible(true);
		activeStatus = inputOptions[i];
	}

	void createDelay(int duration)
	{
		Timer timer = new Timer(duration, new ActionListener(){
	       public void actionPerformed(ActionEvent e){ System.exit(0);}});
	       timer.setRepeats(false);
	       timer.start();
	}


	public void paintComponent(Graphics g){}

	void commandAdd()
	{
		int type, year, id; double cost; String make, model, status;
		float maxWeight = 0.0f;
		double length = 0.0; 
		double width = 0.0;
		String body = " "; 
		
		type       = isValidVehicle();
		if(type == 1) body = getStr(" BODY TYPE: ");		
		make       = getStr(" Make: ");
		model      = getStr(" Model: ");
		year       = getInt(" Year: ");
		status     = isValidStatus();
		cost       = getDbl("\n Cost: ");
		
		if(type == 2)  
			maxWeight = getFloat(" MAX WEIGHT: ");
		else if(type == 3) {
			length = getDbl(" Length: "); 
			width  = getDbl(" Width: "); 
		}
		
		switch(type)
		{
			case 1:
				Car car = new Car(make, model, year, status, genRandID(), cost, body);
				vehicleList.add(car); break;
			case 2: 
				Truck truck = new Truck(make, model, year, status, genRandID() , cost, maxWeight);
				vehicleList.add(truck); break;
			case 3: 
				Minivan van = new Minivan(make, model, year, status, genRandID() , cost, length, width);
				vehicleList.add(van); break;
		}

		out("\n** Vehicle added **\n\nClick on commands in GUI!\n");
	}

	

	int isValidVehicle()
	{
		int opt = getInt("TYPE OF VEHICLE:\n > 1: CAR\n > 2: TRUCK\n > 3: MINIVAN\n INPUT #: ");
		while( opt != 1 && opt != 2 && opt !=3 )
		{
			out(" [INVALID OPTION]\n");
			opt = getInt("TYPE OF VEHICLE:\n > 1: CAR\n > 2: TRUCK\n > 3: MINIVAN\n INPUT #: ");
		}
		return opt;
	}


	String isValidStatus()
	{
		int opt = getInt("\nSTATUS:\n > 1: RENTAL \n > 2: OUT RENTED\n > 3: IN REPAIRS\n INPUT #: ");
		while(true)
		{
			if(opt == 1 || opt == 2 || opt ==3 ) break;
			else
			{
				out("\n [INVALID OPTION]\n\n");
				opt = getInt(" STATUS:\n > 1: RENTAL \n > 2: OUT RENTED\n > 3: IN REPAIRS\n INPUT #: ");
			}
		}
		
		if(opt == 1) return "RENTAL";
		else if(opt == 2) return "OUT RENTED";
		else if(opt == 3) return "IN REPAIRS";
		return " ";
	}


	float getFloat(String question)
	{
		float value;
		out(question);
		try{ value = getInput.nextFloat(); }
		catch(InputMismatchException error1)
		{
			out("<must be float>");
			value = getFloat(question); }
		return 	value;
	}


	String getStr(String question)
	{
		out(question);
		String body = getInput.next();
		return body;
	}


	int getInt(String question)
	{
		int value;
		out(question);
		try{ value = getInput.nextInt(); }
		catch(InputMismatchException error2)
		{
			out("<must be whole number>");
			value = getInt(question); 
		}
		return 	value;
	}


	double getDbl(String question)
	{
		double value;
		out(question);
		try{ value = getInput.nextDouble(); }
		catch(InputMismatchException error3)
		{
			out("<must be a double>");
			value = getDbl(question); 
		}
		return 	value;
	}




	public void mouseReleased (MouseEvent click) 
	{
		if( (JLabel) click.getSource() == inputOptions[6]) updateCurSettings(6);
	}
	
	int genRandID() { idStart += 1; return idStart; }
	void out(String question) { System.out.print(question); }

	public void mouseClicked  (MouseEvent click) {}  
	public void mousePressed  (MouseEvent click) {} 
	public void mouseEntered  (MouseEvent click) {} 
	public void mouseExited   (MouseEvent click) {}
}