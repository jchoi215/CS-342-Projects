import java.util.Scanner;
import java.util.InputMismatchException;

public class VehicleLinkedList
{
	private node head;
	private node tail;

	private Scanner getInput;

	public VehicleLinkedList()
	{
		head = null; 
		getInput = new Scanner(System.in);
	}

	public void add(Vehicle vehicle){
		if(head == null){
			head = new node(vehicle);	
			tail = head;
		}
		else{		
			node temp = new node(vehicle);
			linkNext(temp);
		}
	}


	private void linkNext(node temp){
		tail.setNext(temp);
		tail = temp;
	}


	public void showList(){
		node temp = head;
		
		if(head == null) errorListEmpty();

		while(temp != null)
		{
			temp.displayInfo(false);
			temp = temp.getNext();
		}
	}


	public void rentable(){
		node temp = head;
		
		if(head == null) errorListEmpty();
		
		while(temp != null)
		{
			temp.displayInfo(true);
			temp = temp.getNext();
		}
	}


	public void updateStatus(int ID){
		node temp = head;
		node targetVehicle = null;

		while(temp != null)
		{	
			if(temp.searchID(ID)) targetVehicle = temp;
			temp = temp.getNext();
		}

		if(targetVehicle == null)
		{
			System.out.println("\n[ID NOT FOUND]");
		}
		else
		{
			System.out.println();
			targetVehicle.displayInfo(false);
			String nStatus = isValidStatus();
			targetVehicle.update(nStatus);
			System.out.println("\nNEW STATUS\n----------\n");
			targetVehicle.displayInfo(false);
		}
	}

	// check if input was valid - for status
	String isValidStatus()
	{
		int opt = getInt(" Change status to:\n > 1: RENTAL\n > 2: OUT RENTED\n > 3: IN REPAIRS\n INPUT #: ");
		while(true)
		{
			if(opt == 1 || opt == 2 || opt ==3 ) break;
			else
			{
				System.out.print("\n [INVALID OPTION]\n\n");
				opt = getInt(" Change status to:\n > 1: RENTAL\n > 2: OUT RENTED\n > 3: IN REPAIRS\n INPUT #: ");
			}
		}
		
		if(opt == 1) return "RENTAL";
		else if(opt == 2) return "OUT RENTED";
		else if(opt == 3) return "IN REPAIRS";
		return " ";
	}

	// scan in an integer from command line
	int getInt(String question)
	{
		int value;
		System.out.print(question);
		try{ value = getInput.nextInt(); }
		catch(InputMismatchException error2)
		{
			System.out.print("<must be whole number>");
			value = getInt(question); 
		}
		return 	value;
	}

	private void errorListEmpty(){
		System.out.println("[LIST IS EMPTY]\n");
	}


	public void deleteList() {head = null; }
}

