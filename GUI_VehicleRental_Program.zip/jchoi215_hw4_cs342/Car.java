import java.text.DecimalFormat;

public class Car extends Vehicle
{		
	private String carType;
	private static DecimalFormat dec2 = new DecimalFormat(".###");

	// constructor for car
	public Car(
		String make, String model, int year, String status, 
		int id, double cost, String carType ){

		super(make, model, year, status, id, cost);	
		this.carType = carType;	
	}

	// isRent == true shows all vehicle that are rentable
	public void info(boolean isRent)
	{	
		if(isRent)
		{
			if(this.status.equals("RENTAL")) _infoHelper();
		}
		else
			_infoHelper();	
	}


	// display car information
	public void _infoHelper()
	{
		int ID      = this.id;
		double COST = this.cost;

		System.out.print(" ID: " + ID);
		genSpace( intLength(ID) , 14);
		System.out.print(" COST $" + dec2.format(COST));
		genSpace( 4 , 8);
		System.out.println("[" + this.status + "]");
		System.out.println
		(
			" CAR: " + this.make  + " " + carType + 
			" " + this.model + "\n"
		);
	}

	// get length of number
	int intLength(int value)
	{
		return (Integer.toString(value)).length();
	}

	// using length of number to correct spacing issue
	void genSpace(int x, int maxSpace)
	{
		int limit = maxSpace - x;
		for(int i = 0; i < limit; i++)
		{
			System.out.print(" ");
		} 
	}

	public boolean findID(int id)
	{
		if(this.id == id) return true;
		return false;
	};

	public void update(String newState)
	{
		this.status = newState;
	};
}
