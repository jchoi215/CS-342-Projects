
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.Icon;
import javax.swing.ImageIcon;

public class InterfaceImage extends JPanel
{
	private JLabel[] interfaceArray;
	
	// create "backgrounds" for various states
	public InterfaceImage()
	{
		interfaceArray = new JLabel[7];
		interfaceArray[0] = new JLabel(new ImageIcon("add_v2.jpg"));
		interfaceArray[1] = new JLabel(new ImageIcon("display_v2.jpg"));
		interfaceArray[2] = new JLabel(new ImageIcon("rent_v2.jpg"));
		interfaceArray[3] = new JLabel(new ImageIcon("update_v2.jpg"));
		interfaceArray[4] = new JLabel(new ImageIcon("reset_v2.jpg"));
		interfaceArray[5] = new JLabel(new ImageIcon("exit_v2.jpg"));
		interfaceArray[6] = new JLabel(new ImageIcon("default_v2.jpg"));
		DefaultBehavior();
	}

	// make "backgrounds" not visible and set placements
	void DefaultBehavior()
	{
		for(int i = 0; i < 7; i++)
		{
			interfaceArray[i].setBounds(0, 0, 1000, 700);
			interfaceArray[i].setVisible(false);
		}
	}

	// pass JLabel array when constructed
	JLabel[] getOptions() {return interfaceArray;}
}