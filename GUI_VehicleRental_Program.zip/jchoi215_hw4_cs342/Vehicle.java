public abstract class Vehicle
{
	protected String make;
	protected String model;
	protected int year;
	protected String status;
	protected int id;
	protected double cost;

	public Vehicle(String make, String model, int year, String status, int id, double cost)
	{
		this.make   = make;
		this.model  = model;
		this.year   = year;
		this.status = status;
		this.id     = id;
		this.cost   = cost;
	}

	abstract public void info(boolean isRent);
	abstract public boolean findID(int id);	
	abstract public void _infoHelper();
	abstract public void update(String newState);
}
