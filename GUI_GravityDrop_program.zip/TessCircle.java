import java.util.List;
import java.util.ArrayList;
import java.awt.Graphics;
import java.awt.Color;
import java.lang.Math.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Polygon;

public class TessCircle extends RulesThatGovernProgram 
{
	Point   center;
	Polygon polyCircle;
	double  radius;
	Force   momentum;
	int numPoints;

	public TessCircle(int numPoints, double radius, Point center)
	{
		double rotateBy = 0;
		this.center = center;
		this.radius = radius;
		this.numPoints = numPoints;
		momentum = new Force();

		int[] xPoints = new int[numPoints];
		int[] yPoints = new int[numPoints];
	
		double numSlices = (2* Math.PI / numPoints);

		if(numPoints == 4) {rotateBy = Math.PI / 4; }

		for(int i = 0; i < numPoints; i++)
		{
			double angle = numSlices * i;
			double nXPoint  = center.getX() + (radius * Math.cos(angle + rotateBy));
			double nYPoint  = center.getY() + (radius * Math.sin(angle + rotateBy));
			
			xPoints[i] = (int) Math.round(nXPoint);
			yPoints[i] = (int) Math.round(nYPoint);
		}				

		polyCircle = new Polygon(xPoints, yPoints, numPoints);
	}



	public void DrawCircleToScreen(Graphics g)
	{
		g.setColor(Color.WHITE);
		g.drawPolygon(polyCircle);
		g.fillPolygon(polyCircle);
	}


	public void collisionEvent()
	{
		double forceDirection = momentum.yDirForce() + TERMINAL_VELOCITY;
		double distanceFromBorder =center.getY() + radius;
		int lowestPoint = (int)(distanceFromBorder + forceDirection);
		

		if(lowestPoint > HEIGHT)
		{
			forceDirection *= BOUNCE;

			double rotateBy = 0;
			if(numPoints == 4) {rotateBy = Math.PI / 4; }
			double numSlices = (2* Math.PI / numPoints);
			for(int i = 0; i < numPoints; i++)
			{
				double angle = numSlices * i;
				double nXPoint  = center.getX() + (radius * Math.cos(angle + rotateBy));
				double nYPoint  = 1140 - radius + (radius * Math.sin(angle + rotateBy));

				polyCircle.xpoints[i] = (int) Math.round(nXPoint);
				polyCircle.ypoints[i] = (int) Math.round(nYPoint);
			}				
		}
	
		polyCircle.translate (0,(int)forceDirection);
		center.translatePoint(0, forceDirection);	
		momentum.forceYUpdate(forceDirection);
	}


	public double  getRadius(){return radius;}
	public Point   getCenterPoint(){return center;}
	public Polygon getPolygon() {return polyCircle; }
	public void    moveCenterPoint(double dx, double dy){center.translatePoint(dx, dy);}
}