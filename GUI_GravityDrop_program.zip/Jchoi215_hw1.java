
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Jchoi215_hw1 extends RulesThatGovernProgram
{
	private GameScreen controlPanel;   

	public static void main(String[] args) {

		JFrame frame = new JFrame();
		GameScreen controlPanel = new GameScreen();
		controlPanel.setBackground(Color.BLACK);

		frame.add(controlPanel);
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.setTitle("Ball and Physics");
		frame.setSize(WIDTH, HEIGHT);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}