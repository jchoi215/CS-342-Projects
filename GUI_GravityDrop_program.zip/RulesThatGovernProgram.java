public class RulesThatGovernProgram
{
	public static final int WIDTH  = 1600;
	public static final int HEIGHT = 1200;
	
	public static final double INTI_X_FORCE = 3;
	public static final double INTI_Y_FORCE = 0;	

	public static final double TERMINAL_VELOCITY = .3;
	public static final double BOUNCE = -.65;

	public static final int MAX_SIZE_TESS = 50;
	public static final int MIN_SIZE_TESS = 10;
}