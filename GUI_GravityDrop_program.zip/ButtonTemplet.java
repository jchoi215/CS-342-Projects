
  import java.io.File;
  import java.io.IOException;
  import javax.imageio.ImageIO;
  import java.awt.image.BufferedImage;

  import javax.swing.JFrame;
  import javax.swing.JPanel;
  import javax.swing.JLabel;
  import javax.swing.JButton;
  import java.awt.Color;
  import java.awt.Font;

  import javax.swing.Icon;
  import javax.swing.ImageIcon;

  import java.awt.event.ActionEvent;
  import java.awt.event.ActionListener;


  public class ButtonTemplet extends JFrame implements ActionListener
  {
    private JButton upButton;
    private JButton downButton;
    private JLabel  blackBorder;
    private JLabel  lable;

    private int count;
    private int minLimit;
    private String displayText;

    public ButtonTemplet(int posX, int posY, int min, String displayText)
    {
      count = 10;
      minLimit = min;
      this.displayText = displayText;
      upButton = new JButton(new ImageIcon("up_arrow.png"));
      upButton.setContentAreaFilled(false);
      upButton.setBorder(null);
      upButton.setFocusPainted(false);
      upButton.setBorderPainted(false);
      upButton.setBackground(Color.black);

      downButton = new JButton(new ImageIcon("down_arrow.png"));
      downButton.setContentAreaFilled(false);
      downButton.setBorder(null);
      downButton.setFocusPainted(false);
      downButton.setBorderPainted(false);
      downButton.setBackground(Color.black);

      blackBorder = new JLabel();
      blackBorder.setIcon(new ImageIcon("border_img.png"));
      blackBorder.setBackground(Color.GRAY);
      blackBorder.setOpaque(false);

      lable  = new JLabel( displayText );
      lable.setFont(new Font("Serif", Font.BOLD, 32));
      lable.setForeground(Color.BLACK);
      lable.setOpaque(true);


      upButton.setBounds   (posX, 400 + posY, 100, 100);
      downButton.setBounds (posX, 675 + posY, 100, 100);
      blackBorder.setBounds(posX, 515 + posY, 100, 147);
      lable.setBounds      (posX, 515 + posY, 100, 147);

      upButton.addActionListener(this);
      downButton.addActionListener(this);
    }


    public JButton getUpButton()    {return upButton; }
    public JButton getDownButton()  {return downButton;}
    public JLabel  getSizeLabel()   {return lable;}
    public JLabel  getBackgoundLable() {return blackBorder;}


    public void actionPerformed(ActionEvent e) 
    {
      if(e.getSource() == upButton  ) 
      {
        if(count < 50)
        {
          count++;
          lable.setText("    " + count);
        }
      }
      if(e.getSource() == downButton)
      {
        if(count > minLimit)
        {
          count--;
          lable.setText("    " + count);
        }
      }
    }

    public int getCount(){return count;}
    public void setTextOverride(int value){lable.setText("    " + value);}

    public void off()
    {
      upButton.setEnabled(false);
      downButton.setEnabled(false);
    }

    public void on()
    {
      upButton.setEnabled(true);
      downButton.setEnabled(true);
    }
}
