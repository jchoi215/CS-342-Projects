public class Force extends RulesThatGovernProgram
{
	double xForce;
	double yForce;


	public Force()
	{
		xForce = INTI_X_FORCE;
		yForce = INTI_Y_FORCE;
	}

	public void   forceYUpdate(double yForce){this.yForce = yForce;}
	public void   changeXDirection(){ xForce *= -1;}
	public void   changeYDirection(){ yForce *= -1;}
	public double xDirForce(){return xForce;}
	public double yDirForce(){return yForce;}
}