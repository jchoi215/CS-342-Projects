import java.util.List;
import java.util.ArrayList;
import java.util.TimerTask;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

import java.awt.Color;
import java.awt.Polygon;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import java.io.File;
import java.awt.image.BufferedImage;
import java.io.IOException;



public class GameScreen extends JPanel implements ActionListener, MouseListener
{
	private List<TessCircle> objects;

	private Timer gameTimeFlow = new Timer(10, this);

	private ButtonTemplet buttonsForSize;
	private JButton incrSizeButton;
	private JButton decrSizeButton;
	private JLabel  sizeBorder;
	private JLabel  sizeLabel;

	private ButtonTemplet buttonsForPoints;
	private JButton incrPointButton;
	private JButton decrPointButton;
	private JLabel  pointBorder;
	private JLabel  pointLabel;

	private int numSides;

	public GameScreen()
	{
		numSides = 12;
		
		buttonsForSize    = new ButtonTemplet(10,-290,  1,"   Size");
		buttonsForPoints  = new ButtonTemplet(10, 170, 10,"  Point");

		objects = new ArrayList<TessCircle>();

		incrSizeButton  = buttonsForSize.getUpButton();
		decrSizeButton  = buttonsForSize.getDownButton();
		sizeBorder      = buttonsForSize.getBackgoundLable();
		sizeLabel       = buttonsForSize.getSizeLabel();

		incrPointButton  = buttonsForPoints.getUpButton();
		decrPointButton  = buttonsForPoints.getDownButton();
		pointBorder      = buttonsForPoints.getBackgoundLable();
		pointLabel       = buttonsForPoints.getSizeLabel();

		this.setLayout(null);
		this.addMouseListener(this);
		
		this.add(pointBorder);
		this.add(incrPointButton);
		this.add(decrPointButton);
		this.add(pointLabel);

		this.add(sizeBorder);
		this.add(incrSizeButton);
		this.add(decrSizeButton);
		this.add(sizeLabel);
		
		gameTimeFlow.start();
	}


	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		for(TessCircle c: objects)
		{
			c.DrawCircleToScreen(g);
		}
	}


	public void actionPerformed(ActionEvent e)
	{
		for(TessCircle c: objects)
		{
			c.collisionEvent();		
		}
		repaint(); 
	}


	public void mouseClicked  (MouseEvent click) {}  
	public void mousePressed  (MouseEvent click) {} 
	public void mouseEntered  (MouseEvent click) {} 
	public void mouseExited   (MouseEvent click) {}
	

	public void mouseReleased (MouseEvent click)
	{		
		int size    = buttonsForSize.getCount();
		int nPoints = buttonsForPoints.getCount();

		if(click.getButton() == MouseEvent.BUTTON1)
		{			
			if(numSides == 4)
			{
				nPoints = 4;
				buttonsForPoints.setTextOverride(4);
			}

			if(objects.size() == 15) objects.remove(0);

			Point clickOrigin = new Point(click.getX(), click.getY());
			TessCircle testCircle = new TessCircle(nPoints, size, clickOrigin);
			objects.add(testCircle);
		}
		

		if(click.getButton() == MouseEvent.BUTTON3)
		{
			if(numSides == 4)
			{
				numSides = 12;
				objects.clear();
				buttonsForPoints.setTextOverride(nPoints);
				buttonsForPoints.on();
			}
			else
			{
				numSides = 4;
				objects.clear();
				buttonsForPoints.setTextOverride(4);
				buttonsForPoints.off();
			}
		}
	} 
}