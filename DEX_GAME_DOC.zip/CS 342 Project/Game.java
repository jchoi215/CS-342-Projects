public class Game{
	public static void main(String [] args){
		Player p1 = new Player();
		p1.playerInfo();
		Player p2 = new Player("Tim", 15, 120, 5.0);
		p2.playerInfo();

	}
}